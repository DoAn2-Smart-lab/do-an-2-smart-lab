# Master Orchestrator Agent

Trạng thái: 🔴 CHƯA VIẾT CODE — chỉ có kế hoạch. Việc code thật bắt đầu ở Tuần 3-4, thực hiện
bằng Claude Code trong VSCode (không phải ở phiên Cowork này).

## Nhiệm vụ
- Nhận lệnh từ Chat (trước) và Voice (Tuần 12) từ người dùng (giảng viên/KTV/sinh viên).
- Intent Recognition: phân loại lệnh thành 1 trong các nhóm ứng với 3 sub-agent.
- Định tuyến (routing) yêu cầu qua MQTT topic `lab/orchestrator/intent`.
- KHÔNG được phép gọi PLC trực tiếp — mọi việc liên quan an toàn phải qua Safety Agent.

## Công nghệ dự kiến
LangGraph (state machine) + FastAPI AsyncIO (nhận request từ giao diện Chat).

## Việc cần làm khi bắt đầu (ở VSCode)
1. Định nghĩa state graph LangGraph: node `receive_input` → `classify_intent` → `route_to_agent`
   → `wait_response` → `reply_user`.
2. Viết bộ phân loại intent tối thiểu (rule-based hoặc SLM local — xem
   `docs-thiet-ke/Tong-hop-y-tuong-Zalo-va-dinh-huong-tiep-theo.md` mục 2) cho 4 nhóm lệnh mẫu.
3. Test bằng 4 kịch bản lệnh khác nhau (tiêu chí nghiệm thu #1 trong đề cương).
