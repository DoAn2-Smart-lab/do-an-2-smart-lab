# HANDOFF LOG — Đồ án 2

## 2026-09-17
- Nhận tài liệu định hướng Đồ án 2 từ ThS. Trần Trung Khánh (ban hành 14/09/2026): Nhóm 05 chuyển
  sang xây Hệ thống Đa Agent quản trị phòng thí nghiệm, 4 Agent cốt lõi.
- Soạn và nộp đề cương chi tiết Đồ án 2 (mục tiêu, sơ đồ khối, phân công, kế hoạch 15 tuần).
- Thu thập ý tưởng bổ sung của nhóm qua Zalo (Thành Phát): Local AI, CSDL thiết bị chi tiết, upload
  tài liệu, Digital Twin/CAD qua Claude MCP — đã đối chiếu và ghi rõ ý nào nằm trong phạm vi Đồ án
  2, ý nào để dành cho Khóa luận tốt nghiệp.
- Dựng khung thư mục dự án `Do-an-2-he-thong-da-agent-ptn-thong-minh/`.

- Soạn dự thảo Event Bus/MQTT topic schema, `requirements.txt`, README kế hoạch cho 4 Agent.
- Soạn bảng phân định "làm ở Cowork" vs "bắt buộc chuyển sang Claude Code/VSCode" theo từng tuần.

## Việc tiếp theo (Tuần 1 — chuyển sang Claude Code/VSCode)
- [ ] Cài đặt môi trường: LangGraph, FastAPI AsyncIO, MQTT broker (Mosquitto).
- [ ] Rà soát lại code Đồ án 1 để xác định phần cần nâng cấp cho Safety Agent.
- [ ] `git init` cho thư mục Đồ án 2, commit lần đầu.
- [ ] Mở Claude Code trong VSCode tại thư mục `Do-an-2-he-thong-da-agent-ptn-thong-minh/`, dán
  câu lệnh ngữ cảnh trỏ tới `PROJECT_CONTEXT.md` để bắt đầu.
